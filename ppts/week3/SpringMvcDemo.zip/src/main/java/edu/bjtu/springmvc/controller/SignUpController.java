package edu.bjtu.springmvc.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.bjtu.springmvc.model.SignUpForm;

/**
 * SignUpController class for User sign up form processing
 * 
 * @author Ramesh Fadatare
 */
@Controller
public class SignUpController {

	/**
	 * Create new signUpForm object for empty from
	 * 
	 * @return
	 */
	@ModelAttribute("signUpForm")
	public SignUpForm setSignUpForm() {
		return new SignUpForm();
	}


	/**
	 * Method to show the initial HTML form
	 * 
	 * @return
	 */
	@GetMapping("/showSignUpForm")
	public String showForm() {
		return "signup-form";
	}

	/**
	 * Save User sign up form
	 * 
	 * @param signUpForm
	 * @param model
	 * @return
	 */
	//@PostMapping("/saveSignUpForm")
	@RequestMapping(value = "/saveSignUpForm", method = RequestMethod.POST)
	public ModelAndView saveUser(@ModelAttribute("signUpForm") SignUpForm signUpForm) {

		// Implement business logic to save user details into a database
		// .....

		System.out.println("FirstName : " + signUpForm.getFirstName());
		System.out.println("LastName : " + signUpForm.getLastName());
		System.out.println("Username : " + signUpForm.getUserName());
		System.out.println("Password : " + signUpForm.getPassword());
		System.out.println("Email : " + signUpForm.getEmail());
         
		 //model = new HashMap();
		//model.addAttribute("message", "User SignUp successfully.");
		//model.addAttribute("user", signUpForm);

		//return "signup-success";
		//return new ModelAndView("signup-success", "userinfo", model);
		
		ModelAndView mv = new ModelAndView();
        mv.setViewName("signup-success");
        mv.addObject("message", "SignUp Successful.");
        mv.addObject("user", signUpForm);
        //mv.getModel().put("message", "SignUp Successful.");
        //mv.getModel().put("user", signUpForm);
 
        return mv;
	}
	
	@RequestMapping(value = "/evening", method = RequestMethod.GET)
	public String evening(Model model) {
		model.addAttribute("message", "Good Evening!!!");

		return "welcome";
	}

}
