package edu.bjtu.IocSample1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import edu.bjtu.IocSample1.customer.Customer;;

/**
 * Hello world!
 *
 */
public class App 
{
    @SuppressWarnings("resource")
	public static void main( String[] args )
    {
		// loading the definitions from the given XML file
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"SpringBeans.xml");
 
		Customer customer = (Customer) context
				.getBean("customerMinna");
		String message = "Customer:" + customer.getPerson().getName() + " Age:"+ customer.getPerson().getAge();
		System.out.println(message);

		Customer customer2 = (Customer) context
				.getBean("customerJava");
		String message2 = "Customer:" + customer2.getPerson().getName() + " Age:"+ customer2.getPerson().getAge();
		System.out.println(message2);
 
    }
}
