package edu.bjtu.IocSample1.customer;

import edu.bjtu.IocSample1.bean.Person;

public class Customer {
    Person person;

    public Customer() {
    }
    
    public Customer(Person person) {
        this.person = person;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}
