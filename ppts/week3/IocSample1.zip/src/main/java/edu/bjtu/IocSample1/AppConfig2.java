package edu.bjtu.IocSample1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import edu.bjtu.IocSample1.bean.Person;
import edu.bjtu.IocSample1.customer.Customer;

@Configuration
@ComponentScan("edu.bjtu.IocSample1.customer")
public class AppConfig2 {

	@Autowired
	@Bean(name = "customerJava")
    Customer customer(@Qualifier("personTom") Person p){
        Customer c = new Customer();
        c.setPerson(p);
        return c;
    }
}
