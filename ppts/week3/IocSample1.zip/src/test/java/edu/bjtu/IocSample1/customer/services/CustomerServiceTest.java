package edu.bjtu.IocSample1.customer.services;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.junit.Assert.*;

public class CustomerServiceTest {
    ApplicationContext context;

    @Before
    public void setUp() throws Exception {
        context = new ClassPathXmlApplicationContext("SpringBeans.xml");
    }

    @Test
    public void testSingleton() throws Exception{
        String message = "singleton";
        String expected = message;

        CustomerService service =(CustomerService)context.getBean("customerService");
        service.setMessage(message);
        CustomerService service1 = (CustomerService)context.getBean("customerService");
        String actual = service1.getMessage();

        assertEquals(expected, actual);
    }

    @Test
    public void testPrototype() throws Exception{
        String message = "prototype";
        String expected = null;

        CustomerService service =(CustomerService)context.getBean("customerServicePro");
        service.setMessage(message);
        CustomerService service1 = (CustomerService)context.getBean("customerServicePro");
        String actual = service1.getMessage();

        assertEquals(expected, actual);
    }
}