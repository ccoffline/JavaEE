package edu.bjtu.IocSample1.collections;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.junit.Assert.*;

public class CollectionClassTest {
    ApplicationContext context;

    @Before
    public void setUp() throws Exception {
        context = new ClassPathXmlApplicationContext("Collections.xml");
    }

    @Test
    public void testSize() throws Exception{
        CollectionClass collectionClass = (CollectionClass)context.getBean("collectionClass");

        assertEquals(4, collectionClass.getLists().size());
        assertEquals(3, collectionClass.getSets().size());
        assertEquals(3, collectionClass.getMaps().size());
        assertEquals(2, collectionClass.getPros().size());
    }
}